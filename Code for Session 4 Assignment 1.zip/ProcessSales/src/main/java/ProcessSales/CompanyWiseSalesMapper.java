package ProcessSales;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class CompanyWiseSalesMapper  extends Mapper<LongWritable, Text, Text, IntWritable> {

	@Override
	protected void map(LongWritable in_key, Text in_value, Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		String[] tokenizeValue = in_value.toString().split("\\|"); 
		if (tokenizeValue.length > 2) {

			if (!(tokenizeValue[0].contains("NA") || tokenizeValue[1].contains("NA"))) {
				context.write(new Text(tokenizeValue[0]), new IntWritable(1));
			}
		}
	}

}

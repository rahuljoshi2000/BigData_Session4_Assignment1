package ProcessSales;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class SalesDriver {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws IOException {
		System.out.println("Mapper that outputs only valid records");
		
		Job job = new Job();
		job.setMapperClass(SalesMapper.class);
		job.setJarByClass(SalesDriver.class);
		
		FileInputFormat.setInputPaths(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		job.setOutputKeyClass(LongWritable.class);
		job.setOutputValueClass(Text.class);
		job.setMapOutputKeyClass(LongWritable.class);
		job.setMapOutputValueClass(Text.class);
		try {
			System.exit(job.waitForCompletion(true) ? 0 : 1);
		}
		catch(ClassNotFoundException cnfe) {
			
		}
		catch(InterruptedException inte) {
			
		}
	}
}

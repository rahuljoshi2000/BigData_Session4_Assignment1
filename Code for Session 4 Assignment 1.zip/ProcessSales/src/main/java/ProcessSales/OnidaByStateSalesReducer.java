package ProcessSales;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class OnidaByStateSalesReducer extends Reducer<Text, IntWritable,Text, IntWritable> {

	@Override
	protected void reduce(Text in_key, Iterable<IntWritable> in_value,
			Context context) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		int sum_value = 0;
		for(IntWritable node_value:in_value){
			sum_value += Integer.parseInt(node_value.toString());
		}
		context.write(in_key, new IntWritable(sum_value));
	}
}


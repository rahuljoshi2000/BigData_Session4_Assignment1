package ProcessSales;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SalesMapper extends Mapper<LongWritable, Text, LongWritable, Text> {

	@Override
	protected void map(LongWritable in_key, Text in_value, Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		String[] tokenizeValue = in_value.toString().split("\\|"); 
		if (tokenizeValue.length > 2) {

			if (!(tokenizeValue[0].contains("NA") || tokenizeValue[1].contains("NA"))) {
				context.write(in_key, new Text(tokenizeValue[0] + "|" + tokenizeValue[1]+"|" + tokenizeValue[2] + "|" + tokenizeValue[3]+ "|" + tokenizeValue[4]+ "|" + tokenizeValue[5]));
			}
		}
	}

}
